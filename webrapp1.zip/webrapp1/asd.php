<?php
include('_function.php');

 $conn =  getDBconnection ();


if(isset($_POST['btnSearch']))
{
  $name = $_POST['name'];
  $sqlpname = "SELECT * FROM form WHERE  name LIKE  '%$name%'";
$result2 = mysqli_query($conn , $sqlpname);
  if (mysqli_num_rows($result2) > 0) {
                                    foreach ($result2 as $row) {
header("location:asd.php");

                                    }

                                } else {
                                    echo "<script>alert('Sorry !! No Found')</script>";
                                }
                            }

                        ?>


Product Name : <?php echo $row['email'] ?> <br>
Product Type : <?php echo $row['mobile'] ?> <br>
Place : <?php echo $row['name'] ?> <br>
Contact : <?php echo $row['mdate'] ?> 
Product Name : <?php echo $row['sr'] ?> <br>
Product Type : <?php echo $row['style'] ?> <br>
Place : <?php echo $row['options1'] ?> <br>
Contact : <?php echo $row['options2'] ?>
Product Name : <?php echo $row['description'] ?> <br>
Product Type : <?php echo $row['shape'] ?> <br>
Place : <?php echo $row['colour'] ?> <br>
Contact : <?php echo $row['options3'] ?>
Product Name : <?php echo $row['option4'] ?> <br>
Product Type : <?php echo $row['options5'] ?> <br>
Place : <?php echo $row['options6'] ?> <br>
Contact : <?php echo $row['options7'] ?>
Product Name : <?php echo $row['additional'] ?> <br>
Product Type : <?php echo $row['edate'] ?> <br>
Product Type : <?php echo $row['price'] ?> <br>