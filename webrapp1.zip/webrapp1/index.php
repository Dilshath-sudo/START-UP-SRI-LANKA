<!DOCTYPE html>
<html lang="en">
<html>
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Gemlox</title>

	

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>

<link rel="stylesheet" type="text/css" href="">

<style>
  .btn-success {
  font-size:0.875em;
  display:block;
  left:-60px;
  margin-top:35px;
}


.btn-primary {
   width: 5%;
   min-width: 50px;  // add this if you want
   max-width: 300px; // add this if  you want, adjust accordingly
   min-height: 5px;
}


.btn-secondary {
   width: 10%;
   min-width: 60px;  // add this if you want
   max-width: 300px; // add this if  you want, adjust accordingly
   
}



img {
  width: 50%;
  height: auto;
}



 .txd {
  font-size:15px;

 }

.inpt{
  width: 10%;
   min-width: 80px;  // add this if you want
   max-width: 300px; // add this if  you want, ad
   
}

.inpt1{
  width: 50%;
   min-width: 80px;  // add this if you want
   max-width: 300px; // add this if  you want, ad
}

</style>


</head>

<?php
// insert data into the database 
include('_function.php');


if (isset($_POST['submit'])) {

                            $mobile = $_POST['mobile'];
                            $email = $_POST['email'];
                            $name = $_POST['name'];
                            $mdate = $_POST['mdate'];
                            $sr = $_POST['sr'];
                            $style = $_POST['style'];
                            $options1 = $_POST['options1'];
                            $options2 = $_POST['options2'];
                            $description = $_POST['description'];
                            $shape = $_POST['shape'];
                            $colour = $_POST['colour'];
                            $options3 = $_POST['options3'];
                            $option4 = $_POST['option4'];
                            $options5 = $_POST['options5'];
                            $options6 = $_POST['options6'];
                            $options7 = $_POST['options7'];
                            $additional = $_POST['additional'];
                            $edate = $_POST['edate'];
                            $price = $_POST['price'];

                            

                          $conn =  getDBconnection ();

                    $sql = "INSERT INTO form (mobile,email,name,mdate,sr,style,options1,options2,description,shape,colour,options3,option4,options5,options6,options7,additional,edate,price) VALUES ('$mobile','$email','$name','$mdate','$sr','$style','$options1','$options2','$description','$shape','$colour','$options3','$option4','$options5','$options6','$options7','$additional','$edate' ,'$price')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Insert News Success')</script>";
                                }
                                else {
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }
                          }






?>

<body style="background-color: #F8F8FF;">


  
 
<div style="margin-left:93%; margin-top: 1%;  "><a href="login.php"><button type="submit" class="btn btn-success">Admin</button> </a></div>
	<div style="margin-left: 33%; margin-top: 2%;" ><img class="responsive" src="images/cropped-Transparent-160x45.png" width="400" height="100"></div> <br>
	
	<div style="margin-top: 2%;   color: green; align-content: center;"  class="container">
  
  <div class="well" style="text-align: center; font-size: 20px; font-weight: bold;">CUSTOMER RECORD FORM</div>
</div>

 
  <form action="index.php" method="post" style="margin-top: 2%;">

    <div style="margin-left: 2%; font-weight: bold;">
  <label for="mobile" class="txd">MOBILE No:</label>
  <input type="text" id="gemlox" class="inpt" name="mobile" placeholder="Enter Mobile No" required="">
  
   <label for="email" class="txd" style="margin-left: 15%;">E MAIL:</label>
  <input type="text" id="gemlox" class="inpt" name="email" placeholder="Enter Email" required="">
</div>
<br>


<div style="margin-left: 2%; font-weight: bold;">
  <label for="name" class="txd">NAME:</label>
  <input type="text" id="gemlox" class="inpt"  name="name" placeholder="Enter Name" style="margin-left: 3%;" required="">
  
  <label for="date" class="txd" style="margin-left: 15%;">DATE:</label>
  <input type="date" id="gemlox" class="inpt" name="mdate" placeholder="Enter Date" style="margin-left: 1%;" required="">
  </div>

  <br>

  <div style="margin-left: 2%; font-weight: bold;">
   <label for="sr" class="txd" >SR CODE:</label>
  <input type="text" id="gemlox" class="inpt" name="sr" placeholder="Enter SR Code" style="margin-left: 1.7%;" required="">

  <label for="style" class="txd" style="margin-left: 15%;">STYLE:</label>
  <input type="text" id="gemlox" class="inpt" name="style" placeholder="Enter Style" style="margin-left: 0.5%;" required="">
  </div>

  <div style="margin-left: 2%; margin-top: 2%; font-weight: bold;" class="txd">
  DESCRIPTION: <input class="inpt1" type="text" id="gemlox" name="description" size="100px"  >
  
</div>


<div style="margin-left: 2%; font-weight: bold; margin-top: 2%;">
  <label for="colour" class="txd">COLOUR:</label>
  <input type="text" id="gemlox" class="inpt"  name="colour" placeholder="Enter Colour" required="">
</div>

<div style="margin-left: 2%; font-weight: bold; margin-top: 2%;" class="txd">
  <label for="diamond">TYPE:</label>
 
  
     <select class="form-select" aria-label="Default select example" id="gemlox" name="options1" style="margin-left: 4%; font-weight: bold;">
  <option selected >Open this select menu</option>
  <option value="Platinum"  >Platinum</option>
  <option value="White Gold"    >White Gold</option>
  <option value="Yellow Gold"    >Yellow Gold</option>
  <option value="Rose Gold"    >Rose Gold</option>
  
</select>


  </div>

<div style="margin-left: 2%; font-weight: bold; margin-top: 2%;" class="txd">
  <label for="diamond">K:</label>
 
  
     <select class="form-select" aria-label="Default select example" id="gemlox" name="options2" style="margin-left: 4%; font-weight: bold;">
  <option selected >Open this select menu</option>
  <option value="09K"  >09K</option>
  <option value="14K"    >14K</option>
  <option value="18K"    >18K</option>
  
  
</select>


  </div>



<div style="margin-left: 2%; font-weight: bold; margin-top: 2%;" class="txd">
  <label for="diamond">DIAMOND:</label>
 
  
     <select class="form-select" aria-label="Default select example" id="gemlox" name="shape" style="margin-left: 4%; font-weight: bold;">
  <option selected >Open this select menu</option>
  <option value="Round"  >Round</option>
  <option value="Princess"    >Princess</option>
  <option value="Asscher"    >Asscher</option>
  <option value="Cushion"    >Cushion</option>
  <option value="Heart"    >Heart</option>
  <option value="Oval"    >Oval</option>
  <option value="Radiant"    >Radiant</option>
  <option value="Emerald"    >Emerald</option>
  <option value="Marquise"    >Marquise</option>
  <option value="Pear"    >Pear</option>
</select>


  </div>


  <div style="margin-left: 2%; font-weight: bold; margin-top: 2%;" class="txd">
  <label for="diamond">CUT:</label>
 
  
     <select class="form-select" aria-label="Default select example" id="gemlox" name="options3" style="margin-left: 4%; font-weight: bold;">
  <option selected >Open this select menu</option>
  <option value="Excellent"  >Excellent</option>
  <option value="Very Good"    >Very Good</option>
  <option value="Good"    >Good</option>
  <option value="Fair"    >Fair</option>
  
</select>


  </div>


  <div style="margin-left: 2%; font-weight: bold; margin-top: 2%;" class="txd">
  <label for="diamond">POLISH:</label>
 
  
     <select class="form-select" aria-label="Default select example" id="gemlox" name="option4" style="margin-left: 4%; font-weight: bold;">
  <option selected >Open this select menu</option>
  <option value="Excellent"  >Excellent</option>
  <option value="Very Good"    >Very Good</option>
  <option value="Good"    >Good</option>
  <option value="Fair"    >Fair</option>
  
</select>


  </div>


  <div style="margin-left: 2%; font-weight: bold; margin-top: 2%;" class="txd">
  <label for="diamond">SYMMETRY:</label>
 
  
     <select class="form-select" aria-label="Default select example" id="gemlox" name="options5" style="margin-left: 4%; font-weight: bold;">
  <option selected >Open this select menu</option>
  <option value="Excellent"  >Excellent</option>
  <option value="Very Good"    >Very Good</option>
  <option value="Good"    >Good</option>
  <option value="Fair"    >Fair</option>
  
  
</select>


  </div>

<div style="margin-left: 2%; font-weight: bold; margin-top: 2%;" class="txd">
  <label for="diamond">FLUO:</label>
 
  
     <select class="form-select" aria-label="Default select example" id="gemlox" name="options6" style="margin-left: 4%; font-weight: bold;">
  <option selected >Open this select menu</option>
  <option value="Non"  >Non</option>
  <option value="Faint"    >Faint</option>
  <option value="Medium"    >Medium</option>
  <option value="Strong"    >Strong</option>
  <option value="Very Strong"    >Very Strong</option>
  
  
</select>


  </div>

<div style="margin-left: 2%; font-weight: bold; margin-top: 2%;" class="txd">
  <label for="diamond">CERTIFICATON:</label>
 
  
     <select class="form-select" aria-label="Default select example" id="gemlox" name="options7" style="margin-left: 4%; font-weight: bold;">
  <option selected >Open this select menu</option>
  <option value="Non"  >Non</option>
  <option value="Faint"    >Faint</option>
  <option value="Medium"    >Medium</option>
  
  
  
</select>


  </div>

<div style= "margin-top: 2%; font-weight: bold; margin-left: 2%;" class="txd">
  ADDITIONAL OPTION: <input class="inpt1" type="text" id="gemlox" name="additional" size="100px"  >
  </div>

  <div style="margin-top: 2%; font-weight: bold; margin-left: 2%;">
  <label for="edate" class="txd">EVENT/COMPLITION DATE:</label>
  <input type="date" id="gemlox"  name="edate" placeholder="Enter Event or Complition Date" required="">
</div>

<div style=" font-weight: bold; margin-top: 2%; margin-left: 2%;">
  <label for="colour" class="txd">PRICE:</label>
  <input type="text" class="inpt"  id="gemlox" name="price" placeholder="Enter Price" required="">
</div>

<div style="margin-top: 2%; margin-left: 2%;"><button type="submit" class="btn btn-primary" name="submit">Save</button> &nbsp;&nbsp;&nbsp;
  <button type="submit" class="btn btn-primary" onclick="window.print()" name="print">Print</button> &nbsp;&nbsp;&nbsp;
<button class="btn btn-primary" onclick="document.getElementById('gemlox').value = ''">New</button>

</div>

</form>


<br>
<style>
p {

  background-color: lightgrey;
}
</style>

<p style="text-align: center; font-weight: bold;">Copyright © 2021 Gemlox Developed by Web4rApp Expert Solutions.</p>

</body>
</html>