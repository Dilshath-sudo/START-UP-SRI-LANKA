<?php 

//include("include/header1.php");
include('_function.php');

 ?>

 <!DOCTYPE html>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gemlox</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
  <div style=" margin-left: 2%; margin-top: 1%;  "><a href="index.php"><button type="submit" class="btn btn-success">Logout</button> </a></div>

  <div style="margin-left: 75%;">
    <form action="admin.php" method="post"> 

<input type="text" name="name" placeholder="Email" />
<input type="submit" name="btnSearch" value="Search" />
</form>
</div>

<div style="margin-left: 33%; margin-top: 2%;" ><img src="images/cropped-Transparent-160x45.png" width="400" height="100">

</div> <br>
  <style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 25%;
  padding: 0 10px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #f1f1f1;
}
</style>
</head>



<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #FDFEFE;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #979A9A;
  color: white;
}
</style>
</head>
<body>


  <?php


 $conn =  getDBconnection ();


if(isset($_POST['btnSearch']))
{
  $name = $_POST['name'];
  $sqlpname = "SELECT * FROM form WHERE  name LIKE  '%$name%'";
$result2 = mysqli_query($conn , $sqlpname);
  if (mysqli_num_rows($result2) > 0) {
                                    foreach ($result2 as $row) {
?>

<table id="customers">
  <tr>
    <th>Mobile</th>
    <th>Email</th>
    <th>Name</th>
    <th>Date</th>
    <th>SR Code</th>
    <th>Style</th>
    <th>Type</th>
    <th>K</th>
    <th>Description</th>
    <th>Diamond</th>
    <th>Colour</th>
    <th>Cut</th>
    <th>Polish</th>
    <th>Symmetry</th>
    <th>Fluo</th>
    <th>Certification</th>
    <th>Option</th>
    <th>Event Date</th>
    <th>Price</th>
    

  </tr>

<td> <?php echo $row['email'] ?> </td> 
<td> <?php echo $row['mobile'] ?> </td>
  <td><?php echo $row['name'] ?> </td>
<td> <?php echo $row['mdate'] ?> </td>
 <td><?php echo $row['sr'] ?> </td>
<td><?php echo $row['style'] ?> </td>
 <td><?php echo $row['options1'] ?> </td>
 <td><?php echo $row['options2'] ?></td>
<td><?php echo $row['description'] ?> </td>
 <td><?php echo $row['shape'] ?> </td>
 <td><?php echo $row['colour'] ?> </td>
 <td><?php echo $row['options3'] ?></td>
 <td><?php echo $row['option4'] ?> </td>
 <td><?php echo $row['options5'] ?> </td>
 <td><?php echo $row['options6'] ?> </td>
 <td><?php echo $row['options7'] ?></td>
 <td><?php echo $row['additional'] ?> </td>
 <td><?php echo $row['edate'] ?> </td>
 <td><?php echo $row['price'] ?> </td>

<br> <br>


<?php

                                    }}
                                    echo "<b>Sorry!!! No Found</b> <br>";

}

?>
</table>
<?php

$conn =  getDBconnection ();

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM form WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
         
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
         
    }    
}

?>





  

<br><br>

<?php

$conn =  getDBconnection ();

$sql = "SELECT * FROM form ORDER BY id DESC";
$result = mysqli_query($conn,$sql);

?>

<h2 style="text-align: center; font-weight: bold;">Customer's List With Details</h2> <br>
<table id="customers">
  <tr>
    <th>Mobile</th>
    <th>Email</th>
    <th>Name</th>
    <th>Date</th>
    <th>SR Code</th>
    <th>Style</th>
    <th>Type</th>
    <th>K</th>
    <th>Description</th>
    <th>Diamond</th>
    <th>Colour</th>
    <th>Cut</th>
    <th>Polish</th>
    <th>Symmetry</th>
    <th>Fluo</th>
    <th>Certification</th>
    <th>Option</th>
    <th>Event Date</th>
    <th>Price</th>
    <th>Edit</th>
    

  </tr>

   <?php

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  
  

?>

  <tr>
    <td><?php echo $row['mobile']?></td>
    <td><?php echo $row['email']?></td>
    <td><?php echo $row['name']?></td>
    <td><?php echo $row['mdate']?></td>
    <td><?php echo $row['sr']?></td>
    <td><?php echo $row['style']?></td>
    <td><?php echo $row['options1']?></td>
    <td><?php echo $row['options2']?></td>
    <td><?php echo $row['description']?></td>
    <td><?php echo $row['shape']?></td>
    <td><?php echo $row['colour']?></td>
    <td><?php echo $row['options3']?></td>
    <td><?php echo $row['option4']?></td>
    <td><?php echo $row['options5']?></td>
    <td><?php echo $row['options6']?></td>
    <td><?php echo $row['options7']?></td>
    <td><?php echo $row['additional']?></td>
    <td><?php echo $row['edate']?></td>
    <td><?php echo $row['price']?></td>
    <td>
                <form action="admin.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="delete_btn" class="btn btn-danger"> DELETE</button>
                  <a href="edit.php?id=<?php echo $row['id'] ?>" class="btn btn-primary" >Edit</a>
                </form>
            </td>
  </tr>
  <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No player available')</script>";
                                }

?>
  
</table>
</div></div>


</div>
</div>
</body>
</html>