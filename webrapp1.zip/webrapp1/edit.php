

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gemlox</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php 



 ?>

 <div style="margin-left:15%">



<div class="container" align="center">
  <h2>Edit</h2>



<?php
// insert data into the database 
include('_function.php');

?>












<?php
//getting news form the database tbl_news
$conn =  getDBconnection ();




//updating


if(isset($_POST['update_btn'])){
$id = $_POST['id'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$name = $_POST['name'];
$mdate = $_POST['mdate'];
$sr = $_POST['sr'];
$style = $_POST['style'];
$options1 = $_POST['options1'];
$options2 = $_POST['options2'];
$description = $_POST['description'];
$shape = $_POST['shape'];
$colour = $_POST['colour'];
$options3 = $_POST['options3'];
$option4 = $_POST['option4'];
$options5 = $_POST['options5'];
$options6 = $_POST['options6'];
$options7 = $_POST['options7'];
$additional = $_POST['additional'];
$edate = $_POST['edate'];
$price = $_POST['price'];



$query = "UPDATE form SET mobile = '$mobile' , email = '$email', name = '$name' , mdate = '$mdate', sr = '$sr', style = '$style', options1 = '$options1', options2 = '$options2' , description = '$description' , shape = '$shape' , colour = '$colour' , options3 = '$options3'  , option4 = '$option4'  , options5 = '$options5'  , options6 = '$options6'  , options7 = '$options7'  , additional = '$additional' , edate = '$edate' , price = '$price' WHERE id = $id ";
//$query = "UPDATE tbl_news SET news_description = '$new_desc', desc2 = '$value', desc3 = ''  WHERE id = $id ";
//echo $query;
if (mysqli_query($conn, $query)) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . mysqli_error($conn);
}

}








$id = $_GET['id'];

 $sql = "SELECT * FROM form WHERE id = $id";


  $result = mysqli_query($conn , $sql);

                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {
?>

<div class="alert alert-danger alert-dismissible">
  
    <td>
                <form action="edit.php?id=<?php echo $row['id'] ?>" method="post">
                  <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                  <input name="mobile" value="<?php echo $row['mobile']?>" />
                  <input name="email" value="<?php echo $row['email']?>" />
                  <input name="name" value="<?php echo $row['name']?>" />
                  <input name="mdate" value="<?php echo $row['mdate']?>" />
                  <input name="sr" value="<?php echo $row['sr']?>" />
                  <input name="style" value="<?php echo $row['style']?>" />
                  <input name="options1" value="<?php echo $row['options1']?>" />
                  <input name="options2" value="<?php echo $row['options2']?>" />
                  <input name="description" value="<?php echo $row['description']?>" />
                  <input name="shape" value="<?php echo $row['shape']?>" />
                  <input name="colour" value="<?php echo $row['colour']?>" />
                  <input name="options3" value="<?php echo $row['options3']?>" />
                  <input name="option4" value="<?php echo $row['option4']?>" />
                  <input name="options5" value="<?php echo $row['options5']?>" />
                  <input name="options6" value="<?php echo $row['options6']?>" />
                  <input name="options7" value="<?php echo $row['options7']?>" />
                  <input name="additional" value="<?php echo $row['additional']?>" />
                  <input name="edate" value="<?php echo $row['edate']?>" />
                  <input name="price" value="<?php echo $row['price']?>" /> <br>
                  

                  
                  
                
                  <button type="submit" name="update_btn" class="btn btn-danger"> Update </button>

                 
                </form>
            </td>
  </div>

<?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }


?>

  

</div>
</div>
</body>
</html>
