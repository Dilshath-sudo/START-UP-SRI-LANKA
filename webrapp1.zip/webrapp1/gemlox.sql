-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2021 at 02:04 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gemlox`
--

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE `form` (
  `id` int(10) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mdate` date NOT NULL,
  `sr` varchar(50) NOT NULL,
  `style` varchar(50) NOT NULL,
  `options1` varchar(50) NOT NULL,
  `options2` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `shape` varchar(50) NOT NULL,
  `colour` varchar(50) NOT NULL,
  `options3` varchar(50) NOT NULL,
  `option4` varchar(50) NOT NULL,
  `options5` varchar(50) NOT NULL,
  `options6` varchar(50) NOT NULL,
  `options7` varchar(50) NOT NULL,
  `additional` varchar(1000) NOT NULL,
  `edate` date NOT NULL,
  `price` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form`
--

INSERT INTO `form` (`id`, `mobile`, `email`, `name`, `mdate`, `sr`, `style`, `options1`, `options2`, `description`, `shape`, `colour`, `options3`, `option4`, `options5`, `options6`, `options7`, `additional`, `edate`, `price`) VALUES
(31, '+94755167083', 'mohameddilshath22@gmail.com', 'Mohamed Dilshath', '0000-00-00', '12', 'lki', 'White Gold', '14K', '123456', 'asscher', 'grn', 'Excellent', 'Excellent', 'Excellent', 'Non', 'Non', 'xvzsva', '2021-01-19', ''),
(39, '+94755167083', 'mohameddilshath22@gmail.com', 'Mohamed Dilshath', '2021-01-12', '2', 'lom', 'Platinum', '14K', 'american', 'heart', 'white', 'Very Good', 'YGood', 'Fair', 'Medium', 'Faint', 'no', '2021-01-12', ''),
(46, '+94755167083', 'asd@gmail.com', 'Mohamed Dilshath', '2021-01-13', 'a', 'lki', 'White Gold', '14K', 'i l u', 'round', 'sfasgdae', 'Very Good', 'Very Good', 'Very Good', 'Non', 'Non', 'love', '2021-01-07', ''),
(48, '+94755167083', 'mohameddilshath22@gmail.com', 'Mohamed Dilshath', '2021-01-05', 'degwgw', 'dfdsv', 'White Gold', '14K', 'acsdvs', 'princess', 'ascc', 'Excellent', 'Excellent', 'Fair', 'V.Strong', 'Medium', 'qacc', '2021-01-07', ''),
(51, '+94755167083', 'mohameddilshath22@gmail.com', 'Mohamed Dilshath', '2021-01-05', 'degwgw', 'dfdsv', 'White Gold', '14K', 'acsdvs', 'princess', 'ascc', 'Excellent', 'Excellent', 'Fair', 'V.Strong', 'Medium', 'qacc', '2021-01-07', ''),
(52, '+94755167083', 'mlm@gmail.com', 'Mohamed Dilshath', '2021-01-13', 'asdf', 'ojhgvc', 'White Gold', '14K', 'aA', 'oval', 'sdsd', 'Very Good', 'Excellent', 'Very Good', 'Faint', 'Non', 'XAXX', '2021-01-20', '25000');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(10) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `psw` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `uname`, `psw`) VALUES
(1, 'Mohamed', '789'),
(3, 'dilu', 'dilu'),
(4, 'asd', 'asd'),
(5, 'qwe', 'qwe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `form`
--
ALTER TABLE `form`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
