<?php
                          include('_function.php');

                          if (isset($_POST['signup'])) {

                            $uname = $_POST['uname'];
                            $psw = $_POST['psw'];

                                $conn = getDBconnection();

                                $sql = "SELECT * FROM register WHERE uname = '$uname' AND psw = '$psw'";

                                $result = mysqli_query($conn , $sql);

                                if (mysqli_num_rows($result) > 0) {


                                    foreach ($result as $row) {

                                        
                                        header("location:admin.php");

                                    }

                                } else {
                                    echo "<script>alert('Incorrect Password OR Username')</script>";
                                }
                            }

                        ?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gemlox</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
   
   

   <div class="container"><!-- container begin -->
       <form action="" class="form-login" method="post"><!-- form-login begin -->
           
           <div style="margin-left: 20%;"><img src="images/cropped-Transparent-160x45.png"></div> <br>
           <input type="text" class="form-control" placeholder="Enter Username" name="uname" required>
           
           <input type="password" class="form-control" placeholder="Your Password" name="psw" required>
           
           <button type="submit" class="btn btn-lg btn-primary btn-block" name="signup"><!-- btn btn-lg btn-primary btn-block begin -->
               
               Login
               
           </button><!-- btn btn-lg btn-primary btn-block finish --> <br>

          <div style="margin-left: 40%;"> <a href="register.php">Register</a></div>
           
       </form><!-- form-login finish -->
   </div><!-- container finish -->
    
</body>
</html>