

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Batti CricScore</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php 

include("include/header.php");

 ?>

 <div style="margin-left:15%">



<div class="container" align="center">
  <h2>Player Edit</h2>



<?php
// insert data into the database 
include('../_function.php');

?>












<?php
//getting news form the database tbl_news
$conn =  getDBconnection ();




//updating


if(isset($_POST['update_btn'])){
$id = $_POST['id'];
$player_name = $_POST['player_name'];
$player_photo = $_POST['player_photo'];


$query = "UPDATE tbl_player SET player_name = '$player_name' , player_photo = '$player_photo' WHERE id = $id ";
//$query = "UPDATE tbl_news SET news_description = '$new_desc', desc2 = '$value', desc3 = ''  WHERE id = $id ";
//echo $query;
if (mysqli_query($conn, $query)) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . mysqli_error($conn);
}

}








$id = $_GET['id'];

 $sql = "SELECT * FROM tbl_player WHERE id = $id";


  $result = mysqli_query($conn , $sql);

                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {
?>

<div class="alert alert-danger alert-dismissible">
  
    <td>
                <form action="a_player-edit.php?id=<?php echo $row['id'] ?>" method="post">
                  <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                  <input name="player_name" value="<?php echo $row['player_name']?>" />
                  
                  <input  type="file" name="player_photo" value="<?php echo $row['player_photo']?>" / >
                  
                
                  <button type="submit" name="update_btn" class="btn btn-danger"> Update </button>

                 
                </form>
            </td>
  </div>

<?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }


?>

  





   

  




  




</div>
</div>
</body>
</html>
