

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Batti CricScore</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php 

include("include/header.php");

 ?>

 <div style="margin-left:15%">



<div class="container" align="center">
  <h2>News Update</h2>



<?php
// insert data into the database 
include('../_function.php');


if (isset($_POST['btnAdd'])) {

                            $newsdescription = $_POST['txtnews'];
                          
                          $conn =  getDBconnection ();
                    $sql = "INSERT INTO tbl_news  (news_description) VALUES ('$newsdescription')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Insert News Success')</script>";
                                }
                                else {
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }
                          }






?>

<?php

$conn =  getDBconnection ();

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM tbl_news WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
         
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
         
    }    
}

?>


  <form action="news.php" method="post">
    <div class="form-group">
      
      <input type="text" class="form-control" id="text1" placeholder="Enter News" name="txtnews" required="">
      
    </div>
    <button type="submit" name="btnAdd" class="btn btn-default">Submit</button>
    
  </form>

  <br>
  <h2>View Details</h2>

<div style="margin-left:5%">
  <div class="container" id="slider"><!-- container Begin -->
       
       <div class="col-md-10"><!-- col-md-12 Begin -->
           
           <div class="carousel slide" id="myCarousel" data-ride="carousel"><!-- carousel slide Begin -->
               
               
               
               <div class="carousel-inner"><!-- carousel-inner Begin -->
                  
                   <?php
//$conn =  getDBconnection ();

?>
               
               <a href="#myCarousel" class="left carousel-control" data-slide="prev"><!-- left carousel-control Begin -->
                   
                   <span class="glyphicon glyphicon-chevron-left"></span>
                   <span class="sr-only">Previous</span>
                   
               </a><!-- left carousel-control Finish -->
               
               <a href="#myCarousel" class="right carousel-control" data-slide="next"><!-- left carousel-control Begin -->
                   
                   <span class="glyphicon glyphicon-chevron-right"></span>
                   <span class="sr-only">Next</span>
                   
               </a><!-- left carousel-control Finish -->
               
           </div><!-- carousel slide Finish -->
           
       </div><!-- col-md-12 Finish -->
       
   </div><!-- container Finish -->
</div>
<br><br><br>



  



<?php
//getting news form the database tbl_news

 $sql = "SELECT * FROM tbl_news ORDER BY id DESC";


  $result = mysqli_query($conn , $sql);

                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {
?>

<div class="alert alert-danger alert-dismissible">
    <button type="button" class="close" data-dismiss="success">&times;</button>
    <strong> <?php echo $row['news_description'] ?></strong>(<?php echo $row['created_datetime'] ?>)
    <td>
                <form action="news.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <input type="submit" name="delete_btn" class="btn btn-danger" value="DELETE"/> 

                  <a href="news-edit.php?id=<?php echo $row['id'] ?>" class="btn btn-primary">Edit</a>
                </form>
            </td>
  </div>

<?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }





?>


   

  




   </div>
  </div>




</div>
</div>
</body>
</html>
