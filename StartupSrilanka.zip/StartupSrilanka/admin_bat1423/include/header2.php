<!DOCTYPE html>
<html>
<title>Grow Up Batticaloa</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<!-- Sidebar -->


<!-- Page Content -->


<div class="w3-container w3-teal">
  <h1 style="text-align: center;"><b>Registration</b></h1>






</div>
      
</body>
</html>
