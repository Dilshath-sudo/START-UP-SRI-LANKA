

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Batti CricScore</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php 

include("include/header.php");

 ?>


<div style="margin-left:15%">
<div class="container" align="center">
  <h2>Live Score Update</h2>



<?php
// insert data into the database 
include('../_function.php');


if (isset($_POST['btnAdd'])) {

                            $team_names = $_POST['team_names'];
                            $score = $_POST['score'];
                            $ground = $_POST['ground'];
                          
                          $conn =  getDBconnection ();
                    $sql = "INSERT INTO tbl_live  (team_names,score,ground) VALUES ('$team_names','$score','$ground')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Insert News Success')</script>";
                                }
                                else {
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }
                          }






?>

<?php

$conn =  getDBconnection ();

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM tbl_live WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
         
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
         
    }    
}

?>


  <form action="a_liveScore.php" method="post">
    <div class="form-group">
      
      <input type="text" class="form-control" id="text1" placeholder="Enter Team Names" name="team_names" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Score" name="score" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Ground" name="ground" required="">
      
    </div>
    <button type="submit" name="btnAdd" class="btn btn-default">Submit</button>
  </form>
  <br>

  <h2>View Live Scores</h2>

<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 25%;
  padding: 0 10px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #ABEBC6;
}

.button {
  background-color: black; /* Green */
  border: none;
  color: white;
  padding: 5px;
  text-align: center;
  text-decoration: none;
  
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}


.button4 {border-radius: 12px;}

</style>

</head>








  
</div>
</div>


<br><br>

 
 <?php 

$conn =  getDBconnection ();
$sql = "SELECT * FROM tbl_live";
$result = mysqli_query($conn , $sql);

                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {
?>



<br>
  <div style="margin-right: 5%;">
    <div class="card" style="margin-left:20%">
      <p><?php echo $row['team_names'] ?></p> <br>
      <p><?php echo $row['score'] ?></p>
      <p><?php echo $row['ground'] ?></p> <br>
      <a href="score_card.php"><b>Score Card</b></a><br>
      <td>
                <form action="a_liveScore.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="delete_btn" class="btn btn-danger"> DELETE</button>
                  <a href="live_score-edit.php?id=<?php echo $row['id'] ?>" class="btn btn-primary" >Edit</a>
                </form>
            </td>


       
    </div>
  </div>
</div>

<?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }





?>


 </div></div>

<br><br>


</div>
</div>
</body>
</html>
