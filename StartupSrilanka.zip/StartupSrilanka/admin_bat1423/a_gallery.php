

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Grow Up Batticaloa</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php 

include("include/header.php");

 ?>



<div style="margin-left:15%">
<div class="container" align="center">
  <h2>photos Update</h2>



<?php
// insert data into the database 
include('../_function.php');


if (isset($_POST['btnAd'])) {

                            $teams = $_POST['teams'];
                            $photos = $_POST['photos'];

                          $conn =  getDBconnection ();

                    $sql = "INSERT INTO tbl_gallery  (teams,photos) VALUES ('$teams','$photos')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Insert News Success')</script>";
                                }
                                else {
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }
                          }






?>

<?php

$conn =  getDBconnection ();

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM tbl_gallery WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
         
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
         
    }    
}

?>

  <form action="a_gallery.php" method="post">
    <div class="form-group">
      
      <input type="file" name="teams" required=""><br>
      <input type="file" name="photos" required="">
    </div>
    <button type="submit" name="btnAd" class="btn btn-default">Submit</button>
  </form>
  <br>
  <h2>View Details</h2>

  

<div class="col-md-12"><!-- col-md-6 offer Begin -->


<?php

$conn =  getDBconnection ();

$sql = "SELECT * FROM tbl_gallery";
$result = mysqli_query($conn,$sql);

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  

?>

 


<img src="../images/<?php echo $row['teams']?>" alt="M-dev-Store Logo" class="hidden-xs" height="250" width="400">

<img src="../images/<?php echo $row['photos']?>" alt="M-dev-Store Logo" class="hidden-xs" height="250" width="400">
<td>
                <form action="a_gallery.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="delete_btn" class="btn btn-danger"> DELETE</button>
                  <a href="gallery-edit.php?id=<?php echo $row['id'] ?>" class="btn btn-primary" >Edit</a>
                </form>
            </td>
<?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No player available')</script>";
                                }

?>







</div>

</div></div>
</div></div></div>
</div>



</div>
</div>
</body>
</html>
