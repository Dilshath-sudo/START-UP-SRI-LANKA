



<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>

<?php 

include("include/header.php");

 ?>

 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
  .jumbotron {
    background-color: #f4511e;
    color: #fff;
    padding: 100px 25px;
  }
  .container-fluid {
    padding: 60px 50px;
  }
  .bg-grey {
    background-color: #f6f6f6;
  }
  .logo-small {
    color: #f4511e;
    font-size: 50px;
  }
  .logo {
    color: #f4511e;
    font-size: 200px;
  }
  @media screen and (max-width: 768px) {
    .col-sm-4 {
      text-align: center;
      margin: 25px 0;
    }
  }
  </style>
<body>
<div style="margin-left:15%">
	<div style="margin-top:-3%">
<div class="container-fluid text-center">
  <h1 style="color: green;">SERVICES</h1>
  <h4 style="color: green;">What we do</h4>
  <br><br><br>
  <div class="row">
    <div class="col-sm-4">
      <a href="news.php"><span class="glyphicon  glyphicon-camera  logo-small" ></span></a>
      <h4>NEWS</h4>
      <p>Every Day Update..</p>
    </div>
    <div class="col-sm-4">
      <a href="a_schedule.php"><span class="glyphicon glyphicon-list-alt logo-small"></span></a>
      <h4>SCHEDULE</h4>
      <p>Product Details..</p>
    </div>
    <div class="col-sm-4">
      <a href="admin_registration.php"><span class="glyphicon glyphicon-eye-open logo-small"></span></a>
      <h4>ADMIN REG..</h4>
      <p>Admin Registration Here..</p>
    </div>
  </div>
  <br><br>
  <div class="row">
    <div class="col-sm-4">
      <a href="a_player.php"><span class="glyphicon glyphicon-user logo-small"></span></a>
      <h4>OWNERS</h4>
      <p>Owners Details Add..</p>
    </div>
    <div class="col-sm-4">
      <a href="a_team.php"><span class="glyphicon glyphicon-sort-by-attributes-alt logo-small"></span></a>
      <h4>Product</h4>
      <p>..</p>
    </div>
    <div class="col-sm-4">
     <a href="a_gallery.php"> <span class="glyphicon glyphicon-picture logo-small"></span></a>
      <h4>GALLERY</h4>
      <p>Teams Details Add..</p>
    </div>
  </div>
  <br><br>


  <div class="row">
    <div class="col-sm-4">
      <a href="a_slides.php"><span class="glyphicon glyphicon-signal logo-small"></span></a>
      <h4>Slide</h4>
      <p>Home Page Images..</p>
    </div>
    <div class="col-sm-4">
      <a href="r_batting.php"><span class="glyphicon glyphicon-sort-by-order logo-small"></span></a>
      <h4>RANKING</h4>
      <p>Points Table..</p>
    </div>
    <div class="col-sm-4">
      <a href="index.php"><span  class="glyphicon glyphicon-off logo-small"></span></a>
      <h4 style="color:#303030;">LOGOUT</h4>
      <p>Get Out From Here..</p>
    </div>
  </div>
</div>
</div>
</div>
 

</body>
</html>