

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Batti CricScore</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php 

include("include/header.php");

 ?>

 <div style="margin-left:15%">



<div class="container" align="center">
  <h2>Player Profile Edit</h2>



<?php
// insert data into the database 
include('../_function.php');

?>












<?php
//getting news form the database tbl_news
$conn =  getDBconnection ();




//updating


if(isset($_POST['update_btn'])){
$id = $_POST['id'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$address = $_POST['address'];
$nic = $_POST['nic'];
$bdca_no = $_POST['bdca_no'];
$age = $_POST['age'];
$dob = $_POST['dob'];
$email = $_POST['email'];
$profile_photo = $_POST['profile_photo'];

$query = "UPDATE tbl_playerprofile SET firstname = '$firstname' , lastname = '$lastname', address = '$address' , nic = '$nic', bdca_no = '$bdca_no', age = '$age', dob = '$dob', email = '$email', profile_photo = '$profile_photo' WHERE id = $id ";
//$query = "UPDATE tbl_news SET news_description = '$new_desc', desc2 = '$value', desc3 = ''  WHERE id = $id ";
//echo $query;
if (mysqli_query($conn, $query)) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . mysqli_error($conn);
}

}








$id = $_GET['id'];

 $sql = "SELECT * FROM tbl_playerprofile WHERE id = $id";


  $result = mysqli_query($conn , $sql);

                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {
?>

<div class="alert alert-danger alert-dismissible">
  
    <td>
                <form action="player_profile-edit.php?id=<?php echo $row['id'] ?>" method="post">
                  <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                  <input name="firstname" value="<?php echo $row['firstname']?>" />
                  <input name="lastname" value="<?php echo $row['lastname']?>" />
                  <input name="address" value="<?php echo $row['address']?>" />
                  <input name="nic" value="<?php echo $row['nic']?>" />
                  <input name="bdca_no" value="<?php echo $row['bdca_no']?>" />
                  <input name="age" value="<?php echo $row['age']?>" />
                  <input name="dob" value="<?php echo $row['dob']?>" />
                  <input name="email" value="<?php echo $row['email']?>" />
                  <input  type="file" name="profile_photo" value="<?php echo $row['profile_photo']?>" / >
                
                  <button type="submit" name="update_btn" class="btn btn-danger"> Update </button>

                 
                </form>
            </td>
  </div>

<?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }


?>

  





   

  




  




</div>
</div>
</body>
</html>
