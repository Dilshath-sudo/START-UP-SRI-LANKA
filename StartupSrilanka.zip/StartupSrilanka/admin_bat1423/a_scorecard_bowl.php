

 <!DOCTYPE html>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Batti CricScore</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php 

include("include/header.php");

 ?>

 <div style="margin-left:15%">



<div class="container" align="center">
  <h2>Full Score Card</h2> <br>



<?php
// insert data into the database 
include('../_function.php');


if (isset($_POST['btnAd'])) {

                            
                            $bowling_teams = $_POST['bowling_teams'];
                            $bowler = $_POST['bowler'];
                            $run = $_POST['run'];
                            $madin = $_POST['madin'];
                            $wicket = $_POST['wicket'];
                            $economic = $_POST['economic'];
                            $overs = $_POST['overs'];
                            

                          

                          $conn =  getDBconnection ();

                    $sql = "INSERT INTO tbl_scorebowl  (bowling_teams,bowler,run,madin,wicket,economic,overs) VALUES ('$bowling_teams','$bowler','$run','$madin','$wicket','$economic','$overs')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Insert News Success')</script>";
                                }
                                else {
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }
                          }






?>

<?php

$conn =  getDBconnection ();

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM tbl_scorebowl WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
         
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
         
    }    
}

?>

<div><p>Bowling Details</p></div>

  <form action="a_scorecard_bowl.php" method="post">
    <div class="form-group">
      
      
      <input type="text" class="form-control" id="text1" placeholder="Enter Bowling Team names" name="bowling_teams" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Bowler Name" name="bowler" required=""> <br>
      
      <input type="text" class="form-control" id="text1" placeholder="Enter Provide Runs" name="run" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Madien" name="madin" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Taken wickets" name="wicket" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Overs" name="economic" required=""><br>
      <input type="text" class="form-control" id="text1" placeholder="Enter Overs" name="overs" required=""><br>
      
      
    </div>
    <button type="submit" name="btnAd" class="btn btn-default">Submit</button>
  </form>
  <br>
  <h2>Vies Bowling Scores</h2>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>

<?php


$conn =  getDBconnection ();

?>
           



  
  
</table>
<br><br>

<h2>Bowling</h2>

<table>
  <tr>
    <th>Bowling</th>
    
    <th>O</th>
    <th>R</th>
    <th>M</th>
    <th>W</th>
    <th>Econ</th>
    <th>Edit</th>
  </tr>

  <?php 

$sql = "SELECT * FROM tbl_scorebowl";
$result = mysqli_query($conn , $sql);




                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {


?>

  <tr>
    
    <td><?php echo $row['bowler'] ?></td>
    <td><?php echo $row['run'] ?></td>
    <td><?php echo $row['madin'] ?></td>
    <td><?php echo $row['wicket'] ?></td>
    <td><?php echo $row['economic'] ?></td>
    <td><?php echo $row['overs'] ?></td>
    <td>
                <form action="a_scorecard_bowl.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="delete_btn" class="btn btn-danger"> DELETE</button>
                  <a href="a_scorecard_bowl-edit.php?id=<?php echo $row['id'] ?>" class="btn btn-primary" >Edit</a>
                </form>
            </td>
  </tr>

  <p><?php echo $row['bowling_teams'] ?></p>

   <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }





?>
  
</table>
</div></div>



</div>
</div>
</body>
</html>
