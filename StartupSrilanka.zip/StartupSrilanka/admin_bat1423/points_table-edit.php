

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Batti CricScore</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php 

include("include/header.php");

 ?>

 <div style="margin-left:15%">



<div class="container" align="center">
  <h2>Points Table Edit</h2>



<?php
// insert data into the database 
include('../_function.php');

?>












<?php
//getting news form the database tbl_news
$conn =  getDBconnection ();




//updating


if(isset($_POST['update_btn'])){
$id = $_POST['id'];
$teams = $_POST['teams'];
$played = $_POST['played'];
$won = $_POST['won'];
$lost = $_POST['lost'];
$nr = $_POST['nr'];
$rate = $_POST['rate'];
$points = $_POST['points'];



$query = "UPDATE points_tbl SET teams = '$teams' , played = '$played', won = '$won' , lost = '$lost', nr = '$nr', rate = '$rate', points = '$points' WHERE id = $id ";
//$query = "UPDATE tbl_news SET news_description = '$new_desc', desc2 = '$value', desc3 = ''  WHERE id = $id ";
//echo $query;
if (mysqli_query($conn, $query)) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . mysqli_error($conn);
}

}








$id = $_GET['id'];

 $sql = "SELECT * FROM points_tbl WHERE id = $id";


  $result = mysqli_query($conn , $sql);

                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {
?>

<div class="alert alert-danger alert-dismissible">
  
    <td>
                <form action="points_table-edit.php?id=<?php echo $row['id'] ?>" method="post">
                  <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                  <input name="teams" value="<?php echo $row['teams']?>" />
                  <input name="played" value="<?php echo $row['played']?>" />
                  <input name="won" value="<?php echo $row['won']?>" />
                  <input name="lost" value="<?php echo $row['lost']?>" />
                  <input name="nr" value="<?php echo $row['nr']?>" />
                  <input name="rate" value="<?php echo $row['rate']?>" />
                  <input name="points" value="<?php echo $row['points']?>" />
                  

                  
                  
                
                  <button type="submit" name="update_btn" class="btn btn-danger"> Update </button>

                 
                </form>
            </td>
  </div>

<?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }


?>

  





   

  




  




</div>
</div>
</body>
</html>
