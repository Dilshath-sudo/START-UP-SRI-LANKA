

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Batti CricScore</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php 

include("include/header.php");

 ?>

 <div style="margin-left:15%">




<div class="container" align="center">
  <h2>Teams Points Update</h2>



<?php
// insert data into the database 
include('../_function.php');


if (isset($_POST['btnAd'])) {

                            $names = $_POST['names'];
                            $points = $_POST['points'];

                          $conn =  getDBconnection ();

                    $sql = "INSERT INTO r_teams  (names,points) VALUES ('$names','$points')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Insert News Success')</script>";
                                }
                                else {
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }
                          }
?>
<?php

$conn =  getDBconnection ();

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM r_teams WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
         
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
         
    }    
}

?>

  <form action="r_points.php" method="post">
    <div class="form-group">
      
      <input type="text" class="form-control" id="text1" placeholder="Enter name" name="names" required=""> <br>
      <input type="text" class="form-control" id="text1" placeholder="Enter runs" name="points" required="">
      
    </div>
    <button type="submit" name="btnAd" class="btn btn-default">Submit</button>
  </form>
  <br>
  <h2>View Details</h2>

<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: center;
  padding: 8px;
  height: 50px;
}

tr:nth-child(even){background-color: #FDFEFE}

th {
  background-color: #979A9A;
  color: white;
}


</style>




<?php

$conn =  getDBconnection ();

$sql = "SELECT * FROM r_teams ORDER BY points DESC";
$result = mysqli_query($conn,$sql);

?>


<table>

  <tr>
    <td><b>Position<b></td>
    <td><b>Team<b></td>
    <td><b>points<b></td>
      <td><b>Edit</b></td>
  </tr>
  <?php

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  
  

?>



  <tr>
    <td><?php echo $row['id']?></td>
    <td><?php echo $row['names']?></td>
    <td><?php echo $row['points']?></td>
      <td>
                <form action="r_points.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="delete_btn" class="btn btn-danger"> DELETE</button>
                  <a href="r_points-edit.php?id=<?php echo $row['id'] ?>" class="btn btn-primary" >Edit</a>
                </form>
            </td>
  </tr>
  
  <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No player available')</script>";
                                }

?>
  
</table>
</div></div>
 




</div>
</div>
</body>
</html>
