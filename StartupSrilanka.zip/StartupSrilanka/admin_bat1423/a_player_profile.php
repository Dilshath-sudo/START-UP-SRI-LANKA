

<!DOCTYPE html>


<html>
<title>Grow Up Batticaloa</title>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

<?php
include('../_function.php');
$conn =  getDBconnection ();

$sql = "SELECT * FROM a_reg";
$result = mysqli_query($conn,$sql);

?>

<?php

$conn =  getDBconnection ();

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM a_reg WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
         
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
         
    }    
}

?>



</head>
<body>
<?php 

include("include/header.php");

 ?>
  

 <div style="margin-left:17%">

<h2>Player Profile</h2>

<table>
  <tr>
    <th>User Name</th>
    <th>E-mail</th>
    <th>B-ID No</th>
    <th>Phone No</th>
    <th>Password</th>
    
    <th>Edit</th>
  </tr>

  <?php

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  
  

?>
  <tr>
    <td><?php echo $row['username']?></td>
    <td><?php echo $row['email']?></td>
    <td><?php echo $row['cbid']?></td>
    <td><?php echo $row['phone']?></td>
    <td><?php echo $row['password']?></td>
    
    <td>
                <form action="a_player_profile.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="delete_btn" class="btn btn-danger"> DELETE</button>
                 <button> <a href="player_profile-edit.php?id=<?php echo $row['id'] ?>" class="btn btn-primary" >Edit</a></button>
                </form>
            </td>

  </tr>

  <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No player available')</script>";
                                }

?>
  
</table>
</div>


</body>
</html>
