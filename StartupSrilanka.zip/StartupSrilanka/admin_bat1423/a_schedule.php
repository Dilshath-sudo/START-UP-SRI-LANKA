

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Grow Up Batticaloa</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php 

include("include/header.php");

 ?>

 <div style="margin-left:15%">



<div class="container" align="center">
  <h2> Schedule Update</h2>



<?php
// insert data into the database 
include('../_function.php');



if (isset($_POST['btnAdd'])) {

                            $team = $_POST['team'];
                            $type = $_POST['type'];
                            $tyme = $_POST['tyme'];
                            $ground = $_POST['ground'];
                          
                          $conn =  getDBconnection ();
                    $sql = "INSERT INTO tbl_schedule  (team,type,tyme,ground) VALUES ('$team','$type','$tyme','$ground')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Insert News Success')</script>";
                                }
                                else {
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }
                          }

?>

<?php

$conn =  getDBconnection ();

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM tbl_schedule WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
         
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
         
    }    
}

?>






  <form action="a_schedule.php" method="post">
    <div class="form-group">


      
      <input type="text" class="form-control" id="text1"  placeholder="Enter Product Name" name="team" required=""> <br>

      <input type="text" class="form-control" id="text1"   placeholder="Enter Product Type" name="type" required=""> <br>

      <input type="text" class="form-control" id="text1"  placeholder="Enter Place" name="tyme" required=""> <br>
      
      <input type="text" class="form-control" id="text1"  placeholder="Enter Contact Details" name="ground" required="">
      
    </div>
    <button type="submit" name="btnAdd" class="btn btn-default">Submit</button>
  </form>



  <br><br>

  <h2>View Schedule</h2>

  <style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #FDFEFE;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #979A9A;
  color: white;
}
</style>
</head>
<body>

  

<table id="customers">
  <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Type</th>
    <th>Place</th>
    <th>Contact Details</th>
    <th>Delete</th>

  </tr>

  <?php 

$conn =  getDBconnection ();
$sql = "SELECT * FROM tbl_schedule";
$result = mysqli_query($conn , $sql);




                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {


?>

  <tr>
    <td><?php echo $row['id'] ?></td>
    <td><?php echo $row['team'] ?></td>
    <td><?php echo $row['type'] ?></td>
    <td><?php echo $row['tyme'] ?></td>
    <td><?php echo $row['ground'] ?></td>
    <td>
                <form action="a_schedule.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="delete_btn" class="btn btn-danger"> DELETE</button>
                  <a href="schedule-edit.php?id=<?php echo $row['id'] ?>" class="btn btn-primary" >Edit</a>
                  

                </form>

                


            </td>

  </tr>

  

<?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }





?>

</table>
<br>






</div></div><br>
<br>




</div>
</div>
</body>
</html>
