<?php 

        include('../_function.php');

        if(isset($_POST['Del']))
        {
            $id = $_POST['Del'];
            $query = " delete from tbl_schedule where id = '".$id."'";
            $result = mysqli_query($con,$query);

            if($result)
            {
                header("location:a_gallery.php");
            }
            else
            {
                echo ' Please Check Your Query ';
            }
        }
        else
        {
            header("location:a_player.php");
        }

?>
