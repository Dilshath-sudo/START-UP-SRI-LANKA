

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Batti CricScore</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php 

include("include/header.php");

 ?>

 <div style="margin-left:15%">



<div class="container" align="center">
  <h2>Batting Score Card Edit</h2>



<?php
// insert data into the database 
include('../_function.php');

?>












<?php
//getting news form the database tbl_news
$conn =  getDBconnection ();




//updating


if(isset($_POST['update_btn'])){
$id = $_POST['id'];
$bat_teams = $_POST['bat_teams'];
$teams = $_POST['teams'];
$batsman = $_POST['batsman'];
$howout = $_POST['howout'];
$t_runs = $_POST['t_runs'];
$balls = $_POST['balls'];
$four = $_POST['four'];
$six = $_POST['six'];
$sr = $_POST['sr'];
$extra = $_POST['extra'];
$total = $_POST['total'];


$query = "UPDATE tbl_scorecard SET bat_teams = '$bat_teams' , teams = '$teams', batsman = '$batsman' , howout = '$howout', t_runs = '$t_runs', balls = '$balls', four = '$four', six = '$six', sr = '$sr' , extra = '$extra' , total = '$total' WHERE id = $id ";
//$query = "UPDATE tbl_news SET news_description = '$new_desc', desc2 = '$value', desc3 = ''  WHERE id = $id ";
//echo $query;
if (mysqli_query($conn, $query)) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . mysqli_error($conn);
}

}








$id = $_GET['id'];

 $sql = "SELECT * FROM tbl_scorecard WHERE id = $id";


  $result = mysqli_query($conn , $sql);

                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {
?>

<div class="alert alert-danger alert-dismissible">
  
    <td>
                <form action="a_scorecard-edit.php?id=<?php echo $row['id'] ?>" method="post">
                  <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                  <input name="bat_teams" value="<?php echo $row['bat_teams']?>" />
                  <input name="teams" value="<?php echo $row['teams']?>" />
                  <input name="batsman" value="<?php echo $row['batsman']?>" />
                  <input name="howout" value="<?php echo $row['howout']?>" />
                  <input name="t_runs" value="<?php echo $row['t_runs']?>" />
                  <input name="balls" value="<?php echo $row['balls']?>" />
                  <input name="four" value="<?php echo $row['four']?>" />
                  <input name="six" value="<?php echo $row['six']?>" />
                  <input name="sr" value="<?php echo $row['sr']?>" />
                  <input name="extra" value="<?php echo $row['extra']?>" />
                  <input name="total" value="<?php echo $row['total']?>" />

                  
                  
                
                  <button type="submit" name="update_btn" class="btn btn-danger"> Update </button>

                 
                </form>
            </td>
  </div>

<?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }


?>

  





   

  




  




</div>
</div>
</body>
</html>
