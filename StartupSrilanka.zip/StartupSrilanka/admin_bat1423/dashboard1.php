<!DOCTYPE html>
<html>
<title>Grow Up Batticaloa </title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<body>

<!-- Side Navigation -->


<!-- Header -->
<header class="w3-container w3-theme w3-padding" id="myHeader">
  <i onclick="w3_open()" class="fa fa-bars w3-xlarge w3-button w3-theme"></i> 
  <div class="w3-center">
  
  <h1 class="w3-xxxlarge w3-animate-bottom">Manufacturers / உற்பத்தியாளர்கள்</h1>
    
</header>

<!-- Modal -->
<div id="id01" class="w3-modal">
    <div class="w3-modal-content w3-card-4 w3-animate-top">
      <header class="w3-container w3-theme-l1"> 
        <span onclick="document.getElementById('id01').style.display='none'"
        class="w3-button w3-display-topright">×</span>
       
      </header>
      <div class="w3-padding">
        
      </div>
      
        
      </footer>
    </div>
</div>

<div class="w3-row-padding w3-center w3-margin-top">
<div class="w3-third">
  <div class="w3-card w3-container" style="min-height:460px">
  <a href="admin_registration.php"><h3>Registration / பதிவு</h3><br>
  <i class="fa fa-desktop w3-margin-bottom w3-text-theme" style="font-size:120px"></i></a>
  <p>You Can New Registration Here.</p>
  <p>Do not post new posts to </p>
  <p>anyone without your permission.</p>
  <p>Use this registration method according to the rules</p>
  <br>
  <p>நீங்கள் இங்கே புதிய பதிவு செய்யலாம்.</p>
  <p>எங்கள் அனுமதி இல்லாமல் நீங்களாக </p>
  <p>யாருக்கும் புதிய பதிவிகள் வழங்க வேண்டாம்.</p>
  <p>இப் பதிவு முறையை விதி முறைகளுக்கு ஏற்ப பயன்படுத்தவும்.</p>
  </div>
</div>

<div class="w3-third">
  <div class="w3-card w3-container" style="min-height:460px">
  <a href="a_producter.php"><h3>News Update / செய்தி பதிவிடல்</h3><br>
  <i class="fa fa-css3 w3-margin-bottom w3-text-theme" style="font-size:120px"></i></a>
  <p>You can provide new information and  </p>
  <p>photos related to your products here</p>
  <p>They will be posted on the website </p>
  <p>after being verified</p>
   <br>
  <p>உங்களது உற்பத்திகள் தொடர்பான புதிய தகவல்கள்,</p>
  <p>புகைப்படங்களை இங்கே வழங்க முடியும்.</p>
  <p>அவை சரிபார்க்கப்பட்ட பின்னர் வலைதளத்தில் இடப்படும்.</p>
  </div>
</div>

<div class="w3-third">
  <div class="w3-card w3-container" style="min-height:460px">
  <a href="logout.php"><h3>Logout / வெளியேறு</h3><br>
  <i class="fa fa-diamond w3-margin-bottom w3-text-theme" style="font-size:120px"></i></a>
  <p>You Can Logout Here.</p>
  <p>You must log out </p>
  <p>after completing your work.</p>
  <p>if not, others may misuse.</p>
  <br>
  <p>நீங்கள் இங்கே வெளியேறலாம்.</p>
  <p>உங்கள் வேலை முடிந்ததும் கட்டாயம் </p>
  <p>logout செய்துவிட்டு போகவும்.</p>
  <p>இல்லையென்றால், மற்றவர்கள் தவறாகப் பயன்படுத்தலாம்.</p>
  </div>
</div>
</div>


</script>

</body>
</html>
