-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 28, 2021 at 10:07 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cricscore`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_pass` varchar(255) NOT NULL,
  `admin_image` text NOT NULL,
  `admin_country` text NOT NULL,
  `admin_about` varchar(255) NOT NULL,
  `admin_contact` varchar(255) NOT NULL,
  `admin_job` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `admin_name`, `admin_email`, `admin_pass`, `admin_image`, `admin_country`, `admin_about`, `admin_contact`, `admin_job`) VALUES
(1, 'dilu', 'dilu22@gmail.com', 'dilu1234', 'CI.jpg', 'batti', 'president', '0755167083', 'president');

-- --------------------------------------------------------

--
-- Table structure for table `admin_details`
--

CREATE TABLE `admin_details` (
  `id` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `date` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_details`
--

INSERT INTO `admin_details` (`id`, `username`, `date`) VALUES
(16, 'dilshath', '2020-11-24 13:51:58.087032'),
(17, 'dilshath', '2020-11-24 13:52:10.417835'),
(18, 'dilshath', '2020-11-24 15:11:07.055443'),
(19, 'qqq', '2020-12-25 06:08:01.714054'),
(20, 'dilshath', '2020-12-25 06:08:14.666613'),
(21, 'dilshath', '2020-12-26 04:20:44.328857'),
(22, 'asd', '2020-12-26 17:55:17.548405'),
(23, 'dilshath', '2020-12-26 17:55:26.442961'),
(24, 'dilshath', '2020-12-26 19:23:59.540919'),
(25, 'asd', '2020-12-26 19:48:43.140941'),
(26, 'asd', '2020-12-27 06:27:00.335289'),
(27, 'dilshath', '2020-12-28 04:58:29.757973'),
(28, 'dilshath', '2021-01-17 04:53:16.181075'),
(29, 'dilshath', '2021-01-22 11:17:11.443366'),
(30, 'dilshath', '2021-01-22 12:00:26.606876'),
(31, 'dilshath', '2021-01-22 12:00:37.205573');

-- --------------------------------------------------------

--
-- Table structure for table `a_chatting`
--

CREATE TABLE `a_chatting` (
  `id` int(10) NOT NULL,
  `message1` varchar(1000) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `a_chatting`
--

INSERT INTO `a_chatting` (`id`, `message1`, `date_time`) VALUES
(1, 'rfrgr', '2020-11-23 09:11:53'),
(2, 'rfrgr', '2020-11-23 09:16:23'),
(3, 'yeah sure', '2020-11-23 09:16:31');

-- --------------------------------------------------------

--
-- Table structure for table `a_login`
--

CREATE TABLE `a_login` (
  `id` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cbid` varchar(20) NOT NULL,
  `phone` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `a_reg`
--

CREATE TABLE `a_reg` (
  `id` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cbid` varchar(100) NOT NULL,
  `phone` int(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `a_reg`
--

INSERT INTO `a_reg` (`id`, `username`, `email`, `cbid`, `phone`, `password`) VALUES
(9, 'dilshath', 'Mohameddilshath22@gmail.com', 'asd2345', 755167083, 'dilu1423'),
(12, 'asd', 'asd@gmail.com', 'asd', 0, 'asd');

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `id` int(10) NOT NULL,
  `chatbot` longtext NOT NULL,
  `dates` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`id`, `chatbot`, `dates`) VALUES
(8, '', '2020-11-23 08:34:56'),
(9, '', '2020-11-23 08:35:00');

-- --------------------------------------------------------

--
-- Table structure for table `chatting`
--

CREATE TABLE `chatting` (
  `id` int(10) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messege`
--

CREATE TABLE `messege` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `messege` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messege`
--

INSERT INTO `messege` (`id`, `name`, `email`, `subject`, `messege`) VALUES
(9, 'MOHAMED DILSHATH', 'Mohameddilshath22@gmail.com', 'Trainee Vacancy', 'i have to talk'),
(10, 'Mohamed Dilshath', 'mohameddilshath22@gmail.com', 'I have to Register', 'I am Enterpurber'),
(11, 'Mohamed Dilshath', 'mohameddilshath22@gmail.com', 'I have to Register', 'I am Enterpurber');

-- --------------------------------------------------------

--
-- Table structure for table `points_tbl`
--

CREATE TABLE `points_tbl` (
  `id` int(10) NOT NULL,
  `teams` varchar(100) NOT NULL,
  `played` varchar(100) NOT NULL,
  `won` varchar(100) NOT NULL,
  `lost` varchar(100) NOT NULL,
  `nr` varchar(100) NOT NULL,
  `rate` varchar(100) NOT NULL,
  `points` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `points_tbl`
--

INSERT INTO `points_tbl` (`id`, `teams`, `played`, `won`, `lost`, `nr`, `rate`, `points`) VALUES
(5, 'YHSC', '10', '7', '2', '0', '2.4', '14'),
(9, 'LSSC', '10', '5', '5', '0', '1.1', '10'),
(10, 'YFSC', '10', '7', '3', '0', '1.1', '14'),
(19, 'NFSC', '10', '7', '3', '1', '1.0', '14');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `photo2` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `photo`, `photo2`) VALUES
(1, 'Mohamed Dilshath', '7GPJnews_Srilanka_SDM_wage_84_web-1024x680c.jpg', '14B_fmt.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `id` int(10) NOT NULL,
  `question` longtext NOT NULL,
  `answer` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `r_batting`
--

CREATE TABLE `r_batting` (
  `id` int(10) NOT NULL,
  `position` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `runs` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `r_batting`
--

INSERT INTO `r_batting` (`id`, `position`, `name`, `runs`) VALUES
(24, 'Vegitable', 'Siva', '27'),
(25, 'Coir', 'Ramesh', '24'),
(26, 'Curd', 'Raheem', '22'),
(27, 'Coir', 'Pavithra', '20'),
(28, 'Flowers', 'Aananthi', '17'),
(29, 'Kareem', 'Oil', '13'),
(30, 'priya', 'Flowers', '12');

-- --------------------------------------------------------

--
-- Table structure for table `r_bowling`
--

CREATE TABLE `r_bowling` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `team_name` varchar(100) NOT NULL,
  `wickets` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `r_bowling`
--

INSERT INTO `r_bowling` (`id`, `name`, `team_name`, `wickets`) VALUES
(14, 'Rashid Khan', 'Afganithan', '400'),
(15, 'Mujeeb', 'Afganithan', '380'),
(16, 'Ashwin', 'India', '352'),
(17, 'Strak', 'Australia', '322'),
(18, 'Bumrah', 'India', '300'),
(19, 'Aamer', 'Pakisthan', '375'),
(20, 'P Kumar', 'India', '212'),
(21, 'I Thahir', 'South Africa', '00'),
(22, 'Rabada', 'South Africa', '180');

-- --------------------------------------------------------

--
-- Table structure for table `r_teams`
--

CREATE TABLE `r_teams` (
  `id` int(10) NOT NULL,
  `names` varchar(100) NOT NULL,
  `points` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `r_teams`
--

INSERT INTO `r_teams` (`id`, `names`, `points`) VALUES
(5, 'Australia', '10000'),
(6, 'England', '950'),
(7, 'India', '922');

-- --------------------------------------------------------

--
-- Table structure for table `slide`
--

CREATE TABLE `slide` (
  `slide_id` int(10) NOT NULL,
  `slide_name` varchar(255) NOT NULL,
  `slide_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slide`
--

INSERT INTO `slide` (`slide_id`, `slide_name`, `slide_image`) VALUES
(1, 'slide number 1', 'slide-1.jpg'),
(2, 'slide number 2', 'slide-2.jpg'),
(3, 'slide number 3', 'slide-3.jpg'),
(4, 'slide number 4', 'slide-4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `slide_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery`
--

CREATE TABLE `tbl_gallery` (
  `id` int(10) NOT NULL,
  `teams` varchar(100) NOT NULL,
  `photos` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_gallery`
--

INSERT INTO `tbl_gallery` (`id`, `teams`, `photos`) VALUES
(18, 'download.jpg', 'images.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_live`
--

CREATE TABLE `tbl_live` (
  `id` int(10) NOT NULL,
  `team_names` varchar(100) NOT NULL,
  `score` varchar(100) NOT NULL,
  `ground` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_live`
--

INSERT INTO `tbl_live` (`id`, `team_names`, `score`, `ground`) VALUES
(20, 'asd vs dsa', 'ssc 140/3 (23)', 'Sivananda');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_news`
--

CREATE TABLE `tbl_news` (
  `id` int(5) NOT NULL,
  `news_description` text DEFAULT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `image` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_news`
--

INSERT INTO `tbl_news` (`id`, `news_description`, `created_datetime`, `image`) VALUES
(25, 'Coming Monday (2020:12:28) Domestic Products Exhibition In Batticaloa DS Office - 0773367083.', '2020-12-25 06:35:39', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_player`
--

CREATE TABLE `tbl_player` (
  `id` int(5) NOT NULL,
  `player_name` varchar(50) DEFAULT NULL,
  `player_photo` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_player`
--

INSERT INTO `tbl_player` (`id`, `player_name`, `player_photo`) VALUES
(21, 'K.Rasa', 'nqj3szvgee7tcdakokzz.jpg'),
(22, 'K.Kamala', '7GPJnews_Srilanka_SDM_wage_84_web-1024x680c.jpg'),
(23, 'm.Naser', 'Daily_News_6627269983292.jpg'),
(25, 'N.Sellammaa', 'sri-lanka-housing.jpg'),
(26, 'N.Mursiya', 'download.jpg'),
(27, 'R.Amish', 'humanitarian-srilanka-family.jpg'),
(28, 'AA.Nawas', 'images (1).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_playerprofile`
--

CREATE TABLE `tbl_playerprofile` (
  `id` int(10) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `nic` varchar(20) NOT NULL,
  `bdca_no` varchar(20) NOT NULL,
  `age` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `profile_photo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_recent`
--

CREATE TABLE `tbl_recent` (
  `id` int(10) NOT NULL,
  `team_names` varchar(100) NOT NULL,
  `score` varchar(100) NOT NULL,
  `ground` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_recent`
--

INSERT INTO `tbl_recent` (`id`, `team_names`, `score`, `ground`) VALUES
(6, 'AFSC VS ARSC', 'ARSC 126/4', 'Ahamed Fareed Ground'),
(7, 'lucky vs ssc', 'ssc 140/3 (23)', 'Sivananda'),
(8, 'Yhsc vs Ssc', 'Ssc 200/8 (48)', 'EUSL');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_schedule`
--

CREATE TABLE `tbl_schedule` (
  `id` int(10) NOT NULL,
  `team` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `tyme` varchar(100) NOT NULL,
  `ground` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_schedule`
--

INSERT INTO `tbl_schedule` (`id`, `team`, `type`, `tyme`, `ground`) VALUES
(47, 'Pot', 'Pottery', 'Dhalanguda', '0755167083'),
(48, ' HandLoom Textile', 'Stitching', 'Manmunai', '073367083'),
(49, 'Coir', 'Spinning', 'Kalladi', '0741245865'),
(50, 'Green Peat Coco', 'Furniture', 'Koattamuna', '076789561'),
(51, 'Hnadicrafts Products', 'Snipping', 'Oorani', '0721214521'),
(52, 'Flowers', 'Garden', 'Kalladi', '0755167231'),
(53, 'Mixers', 'Food', 'Kathankudi', '0758956325'),
(54, 'Try Fish', 'Food', 'Valaichenai', '0714565259'),
(55, 'Handloom Bed', 'Furniture', 'Oatamavadi', '0652240360'),
(56, 'Coir', 'Spinning', 'Aarayambathi', '0652240369'),
(57, 'Curd', 'Food', 'Eravur', '0755167083'),
(58, 'Kaju Nuts', 'Food', 'Eravur', '0773367083'),
(59, 'Flowers', 'Garden', 'Kovilkulam', '0652241123'),
(60, 'Pot', 'Pottery', 'Kathangkudi', '0652240456');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_scorebowl`
--

CREATE TABLE `tbl_scorebowl` (
  `id` int(10) NOT NULL,
  `bowling_teams` varchar(100) NOT NULL,
  `bowler` varchar(100) NOT NULL,
  `run` varchar(100) NOT NULL,
  `madin` varchar(100) NOT NULL,
  `wicket` varchar(100) NOT NULL,
  `economic` varchar(100) NOT NULL,
  `overs` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_scorecard`
--

CREATE TABLE `tbl_scorecard` (
  `id` int(10) NOT NULL,
  `bat_teams` varchar(100) NOT NULL,
  `teams` varchar(100) NOT NULL,
  `batsman` varchar(100) NOT NULL,
  `howout` varchar(100) NOT NULL,
  `t_runs` varchar(100) NOT NULL,
  `balls` varchar(100) NOT NULL,
  `four` varchar(100) NOT NULL,
  `six` varchar(100) NOT NULL,
  `sr` varchar(100) NOT NULL,
  `extra` varchar(100) NOT NULL,
  `total` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slides`
--

CREATE TABLE `tbl_slides` (
  `id` int(10) NOT NULL,
  `photos` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_slides`
--

INSERT INTO `tbl_slides` (`id`, `photos`) VALUES
(35, 'Pg17-B.jpg'),
(36, '14B_fmt.jpg'),
(37, 'annai-seafood-02.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_team`
--

CREATE TABLE `tbl_team` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `photo2` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_team`
--

INSERT INTO `tbl_team` (`id`, `name`, `photo`, `photo2`) VALUES
(35, 'Siva - 0652241963', 'p11.jpg', 'p2.jpg'),
(36, 'Ravi - 0755864523', 'p2.jpg', 'p3.jpg'),
(38, 'Umesha - 0652241895', 'p5.jpg', 'pp5.jpg'),
(39, 'Kopi - 0756365254', 'p4.jpg', 'p11.jpg'),
(41, 'Jabbar - 0779865321', 'pp2.jpg', 'pp4.jpg'),
(42, 'Ruthra - 0652240125', 'pp1.jpg', 'pp6.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_team1`
--

CREATE TABLE `tbl_team1` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `photo2` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_team1`
--

INSERT INTO `tbl_team1` (`id`, `name`, `photo`, `photo2`) VALUES
(3, 'Ratha - 0652241023', 'w1.jpg', 'w2.jpg'),
(4, 'Kirusnan - 0765625417', 'w4.jpg', 'w3.jpg'),
(5, 'Mohan - 0720258936', 'w5.jpg', 'w7.jpg'),
(6, 'Mani - 0779865324', 'w8.jpg', 'w6.jpg'),
(7, 'Keerthanan - 0652240741', 'w9.jpg', 'w10.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_team2`
--

CREATE TABLE `tbl_team2` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `photo2` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_team2`
--

INSERT INTO `tbl_team2` (`id`, `name`, `photo`, `photo2`) VALUES
(3, 'Rasa - 0785256415', 'b1.jpg', 'b4.jpg'),
(4, 'Maniyan - 0755452639', 'b2.jpg', 'b8.jpg'),
(5, 'Tasan - 0779863524', 'b3.jpg', 'b5.jpg'),
(6, 'Kather - 0765896427', 'b6.jpg', 'b7.jpg'),
(7, 'Kalyani - 0745632369', 'b9.jpg', 'b10.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_team3`
--

CREATE TABLE `tbl_team3` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `photo2` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_team3`
--

INSERT INTO `tbl_team3` (`id`, `name`, `photo`, `photo2`) VALUES
(2, 'Nadhan - 0778963523', 'c1.jpg', 'c2.jpg'),
(3, 'nadesan - 0769896358', 'c4.jpg', 'c5.jpg'),
(4, 'Isan - 0652241236', 'c8.jpg', 'c9.JPG'),
(5, 'Periyan - 0779865328', 'c10.jpg', 'c11.JPG'),
(6, 'Isman - 0652240362', 'c12.jpg', 'Daily_News_6627269983292.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_team4`
--

CREATE TABLE `tbl_team4` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `photo2` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_team4`
--

INSERT INTO `tbl_team4` (`id`, `name`, `photo`, `photo2`) VALUES
(2, 'Kather - 0765896427', 'd12.jpg', 'd11.jpg'),
(3, 'Najim - 07796352', 'd1.jpg', 'd2.jpg'),
(4, 'Pillai - 0652241235', 'd3.jpg', 'd4.jpg'),
(5, 'Kannan - 0785632698', 'd5.jpg', 'd6.jpg'),
(6, 'Ilangoa - 0758965324', 'd8.jpg', 'd7.jpeg'),
(7, 'Anbu - 0756542897', 'd13.jpg', 'd9.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_team5`
--

CREATE TABLE `tbl_team5` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `photo2` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_team5`
--

INSERT INTO `tbl_team5` (`id`, `name`, `photo`, `photo2`) VALUES
(2, 'Rana - 0756532986', 'aa5.jpg', 'aa6.jpg'),
(3, 'Yaso - 0769865386', 'aa7.jpg', 'aa9.jpg'),
(4, 'Maya - 0756932864', 'aa8.jpg', 'aa11.jpg'),
(5, 'Nivi - 0652248967', 'aa12.jpg', 'aa13.jpg'),
(6, 'Faridha - 0759863585', 'c7.jpg', 'c5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `upcoming`
--

CREATE TABLE `upcoming` (
  `id` int(10) NOT NULL,
  `team_names` varchar(100) NOT NULL,
  `ground` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upcoming`
--

INSERT INTO `upcoming` (`id`, `team_names`, `ground`) VALUES
(3, 'lucky vs ssc', 'Sivananda'),
(4, 'yhsc vs lssc', 'Ahamed Fareed Ground'),
(5, 'Rk vs Ls', 'Santhiveli');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `admin_details`
--
ALTER TABLE `admin_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `a_chatting`
--
ALTER TABLE `a_chatting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `a_login`
--
ALTER TABLE `a_login`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `a_reg`
--
ALTER TABLE `a_reg`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chatting`
--
ALTER TABLE `chatting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messege`
--
ALTER TABLE `messege`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `points_tbl`
--
ALTER TABLE `points_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `r_batting`
--
ALTER TABLE `r_batting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `r_bowling`
--
ALTER TABLE `r_bowling`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `r_teams`
--
ALTER TABLE `r_teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`slide_id`);

--
-- Indexes for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_live`
--
ALTER TABLE `tbl_live`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_news`
--
ALTER TABLE `tbl_news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_player`
--
ALTER TABLE `tbl_player`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_playerprofile`
--
ALTER TABLE `tbl_playerprofile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_recent`
--
ALTER TABLE `tbl_recent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_schedule`
--
ALTER TABLE `tbl_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_scorebowl`
--
ALTER TABLE `tbl_scorebowl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_scorecard`
--
ALTER TABLE `tbl_scorecard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_slides`
--
ALTER TABLE `tbl_slides`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_team`
--
ALTER TABLE `tbl_team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_team1`
--
ALTER TABLE `tbl_team1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_team2`
--
ALTER TABLE `tbl_team2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_team3`
--
ALTER TABLE `tbl_team3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_team4`
--
ALTER TABLE `tbl_team4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_team5`
--
ALTER TABLE `tbl_team5`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `upcoming`
--
ALTER TABLE `upcoming`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin_details`
--
ALTER TABLE `admin_details`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `a_chatting`
--
ALTER TABLE `a_chatting`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `a_login`
--
ALTER TABLE `a_login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `a_reg`
--
ALTER TABLE `a_reg`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `chatting`
--
ALTER TABLE `chatting`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;

--
-- AUTO_INCREMENT for table `messege`
--
ALTER TABLE `messege`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `points_tbl`
--
ALTER TABLE `points_tbl`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `r_batting`
--
ALTER TABLE `r_batting`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `r_bowling`
--
ALTER TABLE `r_bowling`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `r_teams`
--
ALTER TABLE `r_teams`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `slide`
--
ALTER TABLE `slide`
  MODIFY `slide_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_live`
--
ALTER TABLE `tbl_live`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_news`
--
ALTER TABLE `tbl_news`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_player`
--
ALTER TABLE `tbl_player`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tbl_playerprofile`
--
ALTER TABLE `tbl_playerprofile`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_recent`
--
ALTER TABLE `tbl_recent`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_schedule`
--
ALTER TABLE `tbl_schedule`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `tbl_scorebowl`
--
ALTER TABLE `tbl_scorebowl`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_scorecard`
--
ALTER TABLE `tbl_scorecard`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_slides`
--
ALTER TABLE `tbl_slides`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `tbl_team`
--
ALTER TABLE `tbl_team`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `tbl_team1`
--
ALTER TABLE `tbl_team1`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_team2`
--
ALTER TABLE `tbl_team2`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_team3`
--
ALTER TABLE `tbl_team3`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_team4`
--
ALTER TABLE `tbl_team4`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_team5`
--
ALTER TABLE `tbl_team5`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `upcoming`
--
ALTER TABLE `upcoming`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
