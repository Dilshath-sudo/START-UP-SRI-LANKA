<?php 

    $active='gallery';
    include("includes/header.php");

?>

<div style="margin-left: 75%;">
    <form action="ranking.php" method="post"> 

<input type="text" name="name" placeholder=" Name" />
<input type="submit" name="btnSearch" value="Search" />
</form>
</div>

<br>

<div id="content"><!-- #content Begin -->
       <div class="container"><!-- container Begin -->
           <div class="col-md-12"><!-- col-md-12 Begin -->
               
               <ul class="breadcrumb"><!-- breadcrumb Begin -->
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       Ranking
                   </li>
                   
               </ul><!-- breadcrumb Finish -->
               
           </div><!-- col-md-12 Finish -->

          <style>
.button {
  background-color: black; /* Green */
  border: none;
  color: white;
  padding: 5px;
  text-align: center;
  text-decoration: none;
  
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}


.button4 {border-radius: 12px;}

</style>






<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: center;
  padding: 8px;
  height: 50px;

}

tr:nth-child(even){background-color: #FDFEFE}

th {
  background-color: #979A9A;
  color: white;
}


</style>

<?php

include('_function.php');
 $conn =  getDBconnection ();


if(isset($_POST['btnSearch']))
{
  $name = $_POST['name'];
  $sqlpname = "SELECT * FROM r_batting WHERE name LIKE '%$name%'";
$result2 = mysqli_query($conn , $sqlpname);
  if (mysqli_num_rows($result2) > 0) {
                                    foreach ($result2 as $row) {
?>

Player Name : <?php echo $row['name'] ?> <br>
Team Name : <?php echo $row['position'] ?> <br>
Player Runs : <?php echo $row['runs'] ?> <br>

<?php

                                    }}

}

?>

<?php

$conn =  getDBconnection ();

$sql = "SELECT * FROM r_batting ORDER BY runs DESC";
$result = mysqli_query($conn,$sql);

?>


<table>

  <tr>
    <td><b>Manufacturer Name<b></td>
    <td><b> Product Name<b></td>
    <td><b>Points<b></td>
  </tr>
  <?php

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  
  

?>



  
   <tr>
    <td><b><?php echo $row['name']?><b></td>
    <td><b><?php echo $row['position']?><b></td>
    <td><b><?php echo $row['runs']?><b></td>
    
  </tr>
 
  
  
  <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No player available')</script>";
                                }

?>
  
</table>
</div></div><br>
<br>
 <?php 
    
    include("includes/footer.php");
    
    ?>

<script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>