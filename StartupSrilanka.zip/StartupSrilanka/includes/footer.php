<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Grow Up Batticaloa</title>
    <link rel="stylesheet" href="styles/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="styles/style.css">
</head>
<body>

  <div id="footer"><!-- #footer Begin -->
    <div class="container"><!-- container Begin -->
        <div class="row"><!-- row Begin -->
            <div class="col-sm-6 col-md-3"><!-- col-sm-6 col-md-3 Begin -->
               <div id="psd">
              <center> <img src="images/aaaa.png" alt="M-dev-Store Logo" class="hidden-xs" height="55" width="80"></center>
                </div>
                
                
                <hr class="hidden-md hidden-lg hidden-sm">
                
            </div><!-- col-sm-6 col-md-3 Finish -->
            
            <div class="com-sm-6 col-md-3"><!-- col-sm-6 col-md-3 Begin -->
                
                <h4>Keep In Touch</h4>
                
                <p class="social">
                    <a href="https://www.facebook.com/kachcheri.batti" class="fa fa-facebook" target="_blank"></a>
                    <a href="https://twitter.com/actedsrilanka/status/1047352688961249281" class="fa fa-twitter" target="_blank"></a>
                    <a href="https://www.instagram.com/batticaloa/?hl=en" class="fa fa-instagram" target="_blank"></a>
                    
                    <a href="https://mail.google.com/"" class="fa fa-envelope" target="_blank"></a>
                </p>
                
                
                
                <hr class="hidden-md hidden-lg">
                
            </div><!-- col-sm-6 col-md-3 Finish -->
            
            <div class="col-sm-6 col-md-3"><!-- col-sm-6 col-md-3 Begin -->
                
                <h4>Find Us</h4>
                
                <p><!-- p Start -->
                    
                    <strong>BDCA.</strong>
                    <br/>43, Court Road
                    <br/>Batticaloa
                    <br/>065 22 40 120
                    <br/>bdca@gmail.com
                    <br/><strong></strong>
                    
                </p><!-- p Finish -->
                
                <a href="contact.php">Check Our Contact Page</a>
                
                <hr class="hidden-md hidden-lg">
                
            </div><!-- col-sm-6 col-md-3 Finish -->
            
            <div class="col-sm-6 col-md-3">
                
                
                
                <a href="https://www.google.com/maps/place/District+Court+Batticaloa/@7.7100636,81.6951937,16.67z/data=!4m5!3m4!1s0x0:0x1815c68cc6f48eef!8m2!3d7.7123182!4d81.7003562" target="_blank">

                    <img src="images/aaaa.jpg" alt="M-dev-Store Logo" class="hidden-xs" height="200" width="200">   </a>
                
               
                
            </div>
        </div><!-- row Finish -->
    </div><!-- container Finish -->
</div><!-- #footer Finish -->


<div id="copyright"><!-- #copyright Begin -->
    <div class="container"><!-- container Begin -->
        <div class="col-md-6"><!-- col-md-6 Begin -->
            
            <p class="pull-left">&copy; 2010 Batticaloa Distirct Cricket Board Assosiation - All Rights Reserve</p>
            
        </div><!-- col-md-6 Finish -->
        <div class="col-md-6"><!-- col-md-6 Begin -->
            
            
            
        </div><!-- col-md-6 Finish -->
    </div><!-- container Finish -->
</div><!-- #copyright Finish -->

<script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>
</body>
</html>