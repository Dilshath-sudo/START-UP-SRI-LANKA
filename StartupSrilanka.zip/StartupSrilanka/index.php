 <?php 

    
    include("includes/header.php");
    
?>

<?php
//getting news form the database tbl_news
include('_function.php');
 $conn =  getDBconnection ();
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Grow Up Batticaloa</title>
    <link rel="stylesheet" href="styles/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="styles/style.css">
</head>
<body>

   <div id="hot"><!-- #hot Begin -->
       
       <div class="box"><!-- box Begin -->
           
           <div class="container"><!-- container Begin -->
               
               <div class="col-md-12"><!-- col-md-12 Begin -->
                   
                   <center><h2>
                       <b>BATTICALOA  DOMESTIC  INDUSTRIAL PRODUCTS<b>
                   </h2></center>
                   
               </div><!-- col-md-12 Finish -->
               
           </div><!-- container Finish -->
           
       </div><!-- box Finish -->
       
   </div><!-- #hot Finish -->


<div style="margin-left:15%">
	<div class="container" id="slider"><!-- container Begin -->
       
       <div class="col-md-10"><!-- col-md-12 Begin -->
           
           <div class="carousel slide" id="myCarousel" data-ride="carousel"><!-- carousel slide Begin -->
               
               <ol class="carousel-indicators"><!-- carousel-indicators Begin -->
                   
                   <li class="active" data-target="#myCarousel" data-slide-to="0"></li>
                   <li data-target="#myCarousel" data-slide-to="1"></li>
                   <li data-target="#myCarousel" data-slide-to="2"></li>
                   <li data-target="#myCarousel" data-slide-to="3"></li>
                   
               </ol><!-- carousel-indicators Finish -->
               
               <div class="carousel-inner"><!-- carousel-inner Begin -->
                  
                



                   
                   
                                  <?php


$sql = "SELECT * FROM tbl_slides";
$result = mysqli_query($conn,$sql);


$temp = 0;
if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  
?>
                   <div class="item  <?php if($temp == 0){ ?> active <?php } ?>">
                       
                       <img src="images/<?php echo $row['photos']?>" alt="Slider Image 1" width="1000px" >
                       
                   </div>


                       <?php
                              $temp++;      

                                    }
                                } else {
                                    echo "";
                                }

?>
       




                   
                   
                   
               </div><!-- carousel-inner Finish -->
               
               <a href="#myCarousel" class="left carousel-control" data-slide="prev"><!-- left carousel-control Begin -->
                   
                   <span class="glyphicon glyphicon-chevron-left"></span>
                   <span class="sr-only">Previous</span>
                   
               </a><!-- left carousel-control Finish -->
               
               <a href="#myCarousel" class="right carousel-control" data-slide="next"><!-- left carousel-control Begin -->
                   
                   <span class="glyphicon glyphicon-chevron-right"></span>
                   <span class="sr-only">Next</span>
                   
               </a><!-- left carousel-control Finish -->
               
           </div><!-- carousel slide Finish -->
           
       </div><!-- col-md-12 Finish -->
       
   </div><!-- container Finish -->
</div>
<br><br><br>

<?php
//getting news form the database tbl_news

 $sql = "SELECT * FROM tbl_news ORDER BY id DESC";


  $result = mysqli_query($conn , $sql);

                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {
?>

<div class="alert alert-danger alert-dismissible">
    <button type="button" class="close" data-dismiss="success">&times;</button>
    <strong><b> <?php echo $row['news_description'] ?></b></strong> (<?php echo $row['created_datetime'] ?>)
  </div>

<?php
                                    

                                    }
                                } else {
                                    echo "";
                                }





?>


   

  




   </div>
	</div>
<br><br>
 <?php 
    
    include("includes/footer.php");
    
    ?>

	<script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>	
</body>
</html>