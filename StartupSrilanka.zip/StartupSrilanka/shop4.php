<?php 

    $active='shop';
    include("includes/header.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Grow Up Batticaloa</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
</head>
<body>
<div id="content"><!-- #content Begin -->
       <div class="container"><!-- container Begin -->
           <div class="col-md-12"><!-- col-md-12 Begin -->
               
               <ul class="breadcrumb"><!-- breadcrumb Begin -->
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       Food processing
                   </li>
               </ul><!-- breadcrumb Finish -->
               
           </div><!-- col-md-12 Finish -->
<div class="container">
              
  <table class="table table-hover">
    <thead style="color: green;">
      <tr>
        <th>Product & Contact</th> 
        <th><div style="margin-left:  90px;">Product</div></th>
        <th><div style="margin-left:  90px;">Product</div></th>
      </tr>
    </thead>

    <?php 
include('_function.php');
$conn =  getDBconnection ();
$sql = "SELECT * FROM tbl_team4";
$result = mysqli_query($conn , $sql);




                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {


?>
    <tbody>

      <tr>
        <td><div style="margin-top: 60px;"><h3><?php echo $row['name']?></h3></div></td>
        <td><img src="images/<?php echo $row['photo']?>" alt="M-dev-Store Logo" class="hidden-xs" height="200" width="250"></td>
        <td><img src="images/<?php echo $row['photo2']?>" alt="M-dev-Store Logo" class="hidden-xs" height="200" width="250"></td>
      </tr>
      
    </tbody>
    <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }





?>
  </table>
</div>

</body>
</html>
