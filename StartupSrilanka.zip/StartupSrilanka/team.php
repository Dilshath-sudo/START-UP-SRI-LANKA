<?php 

    $active='team';
    include("includes/header.php");

?>

<div style="margin-left: 75%;">
    <form action="team.php" method="post"> 

<input type="text" name="name" placeholder=" Name" />
<input type="submit" name="btnSearch" value="Search" />
</form>
</div>

<br>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 25%;
  padding: 0 10px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #D5F5E3;
}
</style>
</head>
<body>

  <div id="content"><!-- #content Begin -->
       <div class="container"><!-- container Begin -->
           <div class="col-md-12"><!-- col-md-12 Begin -->
               
               <ul class="breadcrumb"><!-- breadcrumb Begin -->
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       Teams
                   </li>
               </ul><!-- breadcrumb Finish -->
               
           </div><!-- col-md-12 Finish -->



<style>
table {
  border-collapse: collapse;
  width: 100%;
 
}

th, td {
  text-align: center;
  padding: 8px;
height: 90px;
font-size: 18px;
}

tr:nth-child(even){background-color: #FDFEFE}

th {
  background-color: #979A9A;
  color: white;
}


</style>


<?php

include('_function.php');
 $conn =  getDBconnection ();


if(isset($_POST['btnSearch']))
{
  $name = $_POST['name'];
  $sqlpname = "SELECT * FROM tbl_team WHERE name LIKE '%$name%'";
$result2 = mysqli_query($conn , $sqlpname);
  if (mysqli_num_rows($result2) > 0) {
                                    foreach ($result2 as $row) {
?>

<?php echo $row['name'] ?> <br>
  <img src="images/<?php echo $row['photo']?>" alt="M-dev-Store Logo" class="hidden-xs" height="80" width="120">
<?php

                                    }}

}

?>

<?php

$conn =  getDBconnection ();

$sql = "SELECT * FROM tbl_team";
$result = mysqli_query($conn,$sql);

?>

<table>

<?php

if (mysqli_num_rows($result) > 0) {
  foreach ($result as $row) {
  
  

?>

  
  <tr>
    <td><?php echo $row['id']?></td>
    <td><a href="https://www.facebook.com/dilshath.mohamed.39"><img src="images/<?php echo $row['photo']?>" alt="M-dev-Store Logo" class="hidden-xs" height="80" width="120"></a></td> 
    <td><b><?php echo $row['name']?><b></td>
  </tr>

 <?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No player available')</script>";
                                }

?>

</table>
</div></div><br>
<br>
 <?php 
    
    include("includes/footer.php");
    
    ?>

</body>
</html>


          

<script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>